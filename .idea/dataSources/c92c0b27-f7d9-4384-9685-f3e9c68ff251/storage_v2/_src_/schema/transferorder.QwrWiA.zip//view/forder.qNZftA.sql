create definer = root@`%` view forder as
select `transferorder`.`client`.`NameZh`   AS `NameZh`,
       `transferorder`.`order`.`orderId`   AS `orderId`,
       `transferorder`.`order`.`sprovince` AS `sprovince`,
       `transferorder`.`order`.`scity`     AS `scity`,
       `transferorder`.`order`.`rprovince` AS `rprovince`,
       `transferorder`.`order`.`rcity`     AS `rcity`,
       `transferorder`.`order`.`sphone`    AS `sphone`,
       `transferorder`.`order`.`semail`    AS `semail`,
       `transferorder`.`order`.`receive`   AS `receive`,
       `transferorder`.`order`.`rphone`    AS `rphone`,
       `transferorder`.`order`.`remail`    AS `remail`,
       `transferorder`.`order`.`check`     AS `check`,
       `transferorder`.`order`.`send`      AS `send`,
       `transferorder`.`order`.`time`      AS `time`
from `transferorder`.`client`
         join `transferorder`.`order`
where (`transferorder`.`client`.`companyCode` = `transferorder`.`order`.`client`);

